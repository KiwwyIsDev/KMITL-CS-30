package packB;

public enum PrintType {
    PRINT, ECOPY;
}
