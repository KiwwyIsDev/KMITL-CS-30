package packB;

public enum Status {
    READY, REPAIRED;
    public String sayHi() {
        return "I am glade you pick me.";
    }
}
