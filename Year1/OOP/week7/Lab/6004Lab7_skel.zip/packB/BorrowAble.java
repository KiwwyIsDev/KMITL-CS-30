package packB;

public interface BorrowAble {
    public boolean checkoutItem(int yy, int mm, int dd);
    public int returnItem(int yy, int mm, int dd);
}
