package packMembership;

public enum MemberType {
    NONE, SILVER, GOLD, PREMIUM
}
