package packMembership;

public interface CanPay {
    public void spend(int direction);
}
